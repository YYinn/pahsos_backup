# python train.py --block_size 64 --note new
# python train.py --block_size 96 --note new
# python train.py --block_size 128 --note new
# python train.py --block_size 160 --note new

python test.py --experiments_name block160_new_2023-03-10T23:36:42 --block_size 160 --evaluation acc
python test.py --experiments_name block160_new_2023-03-10T23:36:42 --block_size 160 --evaluation auc

python test.py --experiments_name block64_new_2023-03-08T21:35:22 --block_size 64 --evaluation acc
python test.py --experiments_name block96_new_2023-03-09T15:40:03 --block_size 96 --evaluation acc
python test.py --experiments_name block128_new_2023-03-10T14:09:58 --block_size 128 --evaluation acc